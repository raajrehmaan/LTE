import Script from "next/script";

export default function HomePage() {
  return (
    <>
      <link rel="stylesheet" href="/clinic/styles.css" />
      <div id="app" />
      <div id="toast" className="toast" role="status" aria-live="polite" />
      <Script src="/clinic/app.js" strategy="afterInteractive" />
    </>
  );
}
