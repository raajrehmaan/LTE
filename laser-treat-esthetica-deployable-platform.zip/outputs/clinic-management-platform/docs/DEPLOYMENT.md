# Laser Treat Esthetica Deployment Guide

This folder is a deployable Next.js/Vercel wrapper for the clinic management app, with Supabase/PostgreSQL schema and PWA assets.

## 1. Production Accounts Needed

- GitHub account and repository.
- Vercel account connected to GitHub.
- Supabase project in the UK/EU region if available.
- DNS access for `lasertreatesthetica.co.uk`.

## 2. Supabase Setup

1. Create a new Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. Go to Project Settings -> API.
5. Copy:
   - Project URL
   - anon public key
   - service role key
6. Enable Email Auth in Authentication -> Providers.
7. Create the first Owner user in Authentication -> Users.
8. Insert the clinic and owner profile:

```sql
insert into public.clinics (name, domain)
values ('Laser Treat Esthetica', 'app.lasertreatesthetica.co.uk')
returning id;

insert into public.profiles (id, clinic_id, full_name, role)
values ('AUTH_USER_UUID_HERE', 'CLINIC_UUID_HERE', 'Owner Name', 'owner');
```

## 3. Environment Variables

Add these in Vercel -> Project -> Settings -> Environment Variables:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEY
NEXT_PUBLIC_APP_URL=https://app.lasertreatesthetica.co.uk
FINANCE_PIN_MIN_LENGTH=4
SESSION_TIMEOUT_MINUTES=30
```

Use the same variables for Preview and Production, except `NEXT_PUBLIC_APP_URL` should point to the preview URL in staging if you want separate staging behavior.

## 4. GitHub + Vercel Deployment

1. Create a GitHub repo, for example `laser-treat-clinic-platform`.
2. Upload this `clinic-management-platform` folder as the repo root.
3. In Vercel, choose Add New Project.
4. Import the GitHub repo.
5. Framework preset: Next.js.
6. Build command: `npm run build`.
7. Output directory: `.next`.
8. Add environment variables.
9. Deploy.

Vercel will create:

- Production deployment on main branch.
- Preview deployments for pull requests.
- Rollback support from the Deployments tab.

## 5. Custom Domain

In Vercel:

1. Open Project -> Settings -> Domains.
2. Add `app.lasertreatesthetica.co.uk`.
3. Vercel will show DNS records.

Typical DNS setup at your domain provider:

```text
Type: CNAME
Name: app
Value: cname.vercel-dns.com
TTL: Auto
```

If Vercel gives a different CNAME target, use Vercel's exact value.

## 6. SSL / HTTPS

Vercel provisions SSL automatically after DNS points to Vercel.

Check:

- `https://app.lasertreatesthetica.co.uk` loads.
- Vercel domain status says Valid Configuration.
- Browser shows a padlock.

## 7. PWA / Installable App

Included:

- `public/manifest.webmanifest`
- `public/icons/icon.svg`
- standalone app mode
- theme color
- Apple web app metadata

After deployment, iPhone/iPad users can:

1. Open the live URL in Safari.
2. Tap Share.
3. Tap Add to Home Screen.

Android users can:

1. Open in Chrome.
2. Tap Install app or Add to Home screen.

Push notifications require a later service worker and provider setup. The current package is push-notification ready at the app structure level, but does not send SMS/WhatsApp/push yet.

## 8. Admin Panel Roadmap

The database supports roles:

- owner
- admin
- therapist
- receptionist

For production, build the Admin Users screen against `profiles` and Supabase Auth Admin API:

- create invited user
- reset password
- disable account
- update role
- audit each action in `audit_logs`

## 9. Security Checklist

Already included:

- Supabase encrypted passwords
- secure sessions through Supabase Auth
- row-level security policies
- role-gated finance tables
- audit log table
- security headers in `next.config.mjs`
- HTTPS through Vercel

Still recommended before clinic go-live:

- Add server-side API validation for every write endpoint.
- Add inactivity timeout in the authenticated layout.
- Add staff invitation flow.
- Add backup export job.
- Add monitoring and error logging.
- Add a real finance PIN hashing table instead of hardcoded demo PIN behavior.

## 10. What I Need To Create The Live URL For You

To deploy from here, provide or connect:

- GitHub repo access
- Vercel account/project access
- Supabase project URL and keys
- DNS provider access or the ability to add the Vercel CNAME

Without those credentials, this package is ready for deployment but cannot be published to a live URL from the local workspace.
