# Laser Treat Esthetica Clinic Platform

Deployable Next.js + Vercel + Supabase package for the clinic management app.

## Local Development

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Production

Follow [docs/DEPLOYMENT.md](./docs/DEPLOYMENT.md).

## Included

- Next.js app shell
- Existing clinic management UI under `public/clinic`
- PWA manifest and app icon
- Supabase/PostgreSQL schema with RLS
- Vercel config
- Environment template
- Health endpoint at `/api/health`
