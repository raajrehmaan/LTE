create extension if not exists "pgcrypto";

create type public.app_role as enum ('owner', 'admin', 'therapist', 'receptionist');
create type public.appointment_status as enum ('scheduled', 'confirmed', 'checked_in', 'in_progress', 'completed', 'cancelled', 'no_show', 'rescheduled');
create type public.payment_status as enum ('unpaid', 'partially_paid', 'deposit_paid', 'paid', 'refunded');
create type public.payment_method as enum ('cash', 'card', 'bank_transfer', 'voucher');
create type public.voucher_source as enum ('none', 'wowcher', 'groupon', 'other');

create table public.clinics (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  domain text unique,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'therapist',
  disabled boolean not null default false,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  full_name text not null,
  phone text not null,
  email text,
  dob date,
  gender text,
  address text,
  emergency_contact text,
  medical_history text,
  allergies text,
  medications text,
  notes text,
  tags text[] not null default '{}',
  vip boolean not null default false,
  referral_source text,
  archived_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.staff (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete set null,
  name text not null,
  role text not null,
  availability text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.treatments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  category text not null,
  treatment text not null,
  variant text not null default 'Standard',
  duration_minutes integer not null check (duration_minutes > 0),
  default_price numeric(10,2) not null check (default_price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  client_id uuid not null references public.clients(id) on delete restrict,
  staff_id uuid not null references public.staff(id) on delete restrict,
  starts_at timestamptz not null,
  duration_minutes integer not null check (duration_minutes > 0),
  status public.appointment_status not null default 'scheduled',
  override_conflict boolean not null default false,
  treatment_plan_notes text,
  notes text,
  internal_notes text,
  base_price numeric(10,2) not null default 0,
  price_override numeric(10,2),
  final_price numeric(10,2) not null default 0,
  deposit numeric(10,2) not null default 0,
  paid_status public.payment_status not null default 'unpaid',
  voucher_source public.voucher_source not null default 'none',
  voucher_code text,
  payment_method public.payment_method,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.appointment_treatments (
  id uuid primary key default gen_random_uuid(),
  appointment_id uuid not null references public.appointments(id) on delete cascade,
  treatment_id uuid not null references public.treatments(id) on delete restrict,
  staff_id uuid references public.staff(id) on delete restrict,
  duration_minutes integer not null check (duration_minutes > 0),
  price numeric(10,2) not null check (price >= 0),
  notes text,
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  appointment_id uuid references public.appointments(id) on delete set null,
  client_id uuid references public.clients(id) on delete set null,
  amount numeric(10,2) not null,
  method public.payment_method not null,
  status public.payment_status not null,
  reference text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid references public.clinics(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create or replace function public.current_profile()
returns public.profiles
language sql
stable
security definer
set search_path = public
as $$
  select * from public.profiles where id = auth.uid() limit 1;
$$;

create or replace function public.current_clinic_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select clinic_id from public.profiles where id = auth.uid() and disabled = false limit 1;
$$;

create or replace function public.current_role()
returns public.app_role
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid() and disabled = false limit 1;
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.current_role() in ('owner', 'admin');
$$;

alter table public.clinics enable row level security;
alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.staff enable row level security;
alter table public.treatments enable row level security;
alter table public.appointments enable row level security;
alter table public.appointment_treatments enable row level security;
alter table public.payments enable row level security;
alter table public.audit_logs enable row level security;

create policy "clinic members can read own clinic" on public.clinics
for select using (id = public.current_clinic_id());

create policy "admins can manage profiles" on public.profiles
for all using (clinic_id = public.current_clinic_id() and public.is_admin())
with check (clinic_id = public.current_clinic_id() and public.is_admin());

create policy "users can read clinic profiles" on public.profiles
for select using (clinic_id = public.current_clinic_id());

create policy "clinic users can read clients" on public.clients
for select using (clinic_id = public.current_clinic_id());

create policy "reception and admins can manage clients" on public.clients
for all using (clinic_id = public.current_clinic_id() and public.current_role() in ('owner', 'admin', 'receptionist'))
with check (clinic_id = public.current_clinic_id() and public.current_role() in ('owner', 'admin', 'receptionist'));

create policy "clinic users can read staff" on public.staff
for select using (clinic_id = public.current_clinic_id());

create policy "admins can manage staff" on public.staff
for all using (clinic_id = public.current_clinic_id() and public.is_admin())
with check (clinic_id = public.current_clinic_id() and public.is_admin());

create policy "clinic users can read treatments" on public.treatments
for select using (clinic_id = public.current_clinic_id());

create policy "admins can manage treatments" on public.treatments
for all using (clinic_id = public.current_clinic_id() and public.is_admin())
with check (clinic_id = public.current_clinic_id() and public.is_admin());

create policy "clinic users can read appointments" on public.appointments
for select using (clinic_id = public.current_clinic_id());

create policy "reception and admins can manage appointments" on public.appointments
for all using (clinic_id = public.current_clinic_id() and public.current_role() in ('owner', 'admin', 'receptionist'))
with check (clinic_id = public.current_clinic_id() and public.current_role() in ('owner', 'admin', 'receptionist'));

create policy "therapists can update assigned appointments" on public.appointments
for update using (clinic_id = public.current_clinic_id() and staff_id in (select id from public.staff where profile_id = auth.uid()))
with check (clinic_id = public.current_clinic_id());

create policy "clinic users can read appointment treatments" on public.appointment_treatments
for select using (appointment_id in (select id from public.appointments where clinic_id = public.current_clinic_id()));

create policy "reception and admins can manage appointment treatments" on public.appointment_treatments
for all using (appointment_id in (select id from public.appointments where clinic_id = public.current_clinic_id()) and public.current_role() in ('owner', 'admin', 'receptionist'))
with check (appointment_id in (select id from public.appointments where clinic_id = public.current_clinic_id()));

create policy "admins can read payments" on public.payments
for select using (clinic_id = public.current_clinic_id() and public.is_admin());

create policy "admins can manage payments" on public.payments
for all using (clinic_id = public.current_clinic_id() and public.is_admin())
with check (clinic_id = public.current_clinic_id() and public.is_admin());

create policy "admins can read audit logs" on public.audit_logs
for select using (clinic_id = public.current_clinic_id() and public.is_admin());

alter publication supabase_realtime add table public.clients;
alter publication supabase_realtime add table public.staff;
alter publication supabase_realtime add table public.treatments;
alter publication supabase_realtime add table public.appointments;
alter publication supabase_realtime add table public.appointment_treatments;
alter publication supabase_realtime add table public.payments;
