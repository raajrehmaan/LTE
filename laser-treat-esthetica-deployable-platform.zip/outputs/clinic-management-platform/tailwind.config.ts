import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        clinicGold: "#c5a46f",
        clinicInk: "#172033",
        clinicCream: "#f8f6f1"
      }
    }
  },
  plugins: []
};

export default config;
