const STORAGE_KEY = "laserTreatClinic.v1";
const CATALOGUE_VERSION = 3;
const LAUNCH_DATA_VERSION = 1;
const FINANCE_PIN = "2468";
const HOUR_HEIGHT = 96;
const CLINIC_START = 11 * 60;
const CLINIC_END = 20 * 60;

const uid = (prefix) => `${prefix}_${Math.random().toString(36).slice(2, 9)}_${Date.now().toString(36)}`;
const todayISO = () => new Date().toISOString().slice(0, 10);
const money = (value) => `£${Number(value || 0).toFixed(2)}`;
const pad = (n) => String(n).padStart(2, "0");
const timeToMinutes = (time) => {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
};
const minutesToTime = (minutes) => `${pad(Math.floor(minutes / 60))}:${pad(minutes % 60)}`;
const niceTime = (time) => {
  const [h, m] = time.split(":").map(Number);
  const suffix = h >= 12 ? "PM" : "AM";
  const hour = h % 12 || 12;
  return `${hour}:${pad(m)} ${suffix}`;
};
const normalize = (value) => String(value || "").trim().toLowerCase();
const slug = (value) => normalize(value).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const treatmentLabel = (treatment) => `${treatment.category} / ${treatment.subcategory && treatment.subcategory !== "General" ? `${treatment.subcategory} / ` : ""}${treatment.name}`;
const treatmentPickerLabel = (treatment) => {
  const display = treatmentDisplayParts(treatment);
  return display.variant === "Standard" ? display.treatment : `${display.treatment} -> ${display.variant}`;
};
const treatmentDuration = (category, subcategory, name) => {
  if (subcategory === "30 Minutes") return 30;
  if (subcategory === "60 Minutes") return 60;
  if (category === "LASER HAIR REMOVAL") {
    if (name === "Full Body") return 120;
    if (["Full Leg", "Full Arm", "Full Face"].includes(name)) return 60;
    return 30;
  }
  if (category === "FACIALS") return ["Gold", "Platinum", "Microneedling"].includes(name) ? 60 : 45;
  if (category === "BODY CONTOURING & FAT REDUCTION") return 45;
  if (category === "AQUALYX FAT DISSOLVING") return 45;
  if (category === "MASSAGE & THERAPY") return subcategory === "60 Minutes" ? 60 : 30;
  if (category === "ADVANCED AESTHETICS") {
    if (subcategory === "IV Drips") return 60;
    if (subcategory === "Dermal Fillers") return 45;
    if (subcategory === "PRP / RPF / Exosomes") return name.includes("6 Sessions") ? 90 : 60;
    return 30;
  }
  return 30;
};
const makeTreatment = (category, subcategory, name, price) => ({
  id: `trt-${slug(`${category}-${subcategory}-${name}`)}`,
  name,
  category,
  subcategory,
  duration: treatmentDuration(category, subcategory, name),
  defaultPrice: price
});

const treatmentCatalogue = () => [
  makeTreatment("FACIALS", "HydraFacial", "Bronze", 80),
  makeTreatment("FACIALS", "HydraFacial", "Silver", 90),
  makeTreatment("FACIALS", "HydraFacial", "Gold", 150),
  makeTreatment("FACIALS", "HydraFacial", "Platinum", 220),
  makeTreatment("FACIALS", "Laser Carbon Peel", "Face", 220),
  makeTreatment("FACIALS", "Laser Carbon Peel", "Back", 220),
  makeTreatment("FACIALS", "Chemical Peel", "Mild", 75),
  makeTreatment("FACIALS", "Chemical Peel", "Medium", 100),
  makeTreatment("FACIALS", "Chemical Peel", "Deep", 140),
  makeTreatment("FACIALS", "Facial Treatments", "Microdermabrasion", 35),
  makeTreatment("FACIALS", "Facial Treatments", "Radiofrequency Skin Tightening", 30),
  makeTreatment("FACIALS", "Facial Treatments", "Microneedling", 150),
  makeTreatment("LASER HAIR REMOVAL", "General", "Upper Lip", 29),
  makeTreatment("LASER HAIR REMOVAL", "General", "Chin", 30),
  makeTreatment("LASER HAIR REMOVAL", "General", "Chest", 30),
  makeTreatment("LASER HAIR REMOVAL", "General", "Stomach", 35),
  makeTreatment("LASER HAIR REMOVAL", "General", "Half Arm", 75),
  makeTreatment("LASER HAIR REMOVAL", "General", "Half Leg", 80),
  makeTreatment("LASER HAIR REMOVAL", "General", "Underarm", 99),
  makeTreatment("LASER HAIR REMOVAL", "General", "Bikini", 120),
  makeTreatment("LASER HAIR REMOVAL", "General", "Full Face", 120),
  makeTreatment("LASER HAIR REMOVAL", "General", "Full Arm", 150),
  makeTreatment("LASER HAIR REMOVAL", "General", "Full Leg", 160),
  makeTreatment("LASER HAIR REMOVAL", "General", "Full Body", 299),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Tattoo Removal", "Very Small", 35),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Tattoo Removal", "Small", 40),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Tattoo Removal", "Medium", 50),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Tattoo Removal", "Large", 100),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Tattoo Removal", "Very Large", 150),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "Hamstring", 50),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "Front Thigh", 50),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "Back Thigh", 50),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "Love Handles", 70),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "Glutes", 75),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "Shoulder Arm", 80),
  makeTreatment("BODY CONTOURING & FAT REDUCTION", "Body Contouring / Fat Reduction", "ABS", 129),
  makeTreatment("AQUALYX FAT DISSOLVING", "General", "Double Chin", 250),
  makeTreatment("AQUALYX FAT DISSOLVING", "General", "Arm", 150),
  makeTreatment("AQUALYX FAT DISSOLVING", "General", "Love Handles", 200),
  makeTreatment("AQUALYX FAT DISSOLVING", "General", "Belly", 300),
  makeTreatment("AQUALYX FAT DISSOLVING", "General", "Thighs", 250),
  makeTreatment("MASSAGE & THERAPY", "30 Minutes", "Massage", 50),
  makeTreatment("MASSAGE & THERAPY", "30 Minutes", "Aroma", 40),
  makeTreatment("MASSAGE & THERAPY", "30 Minutes", "Hot Stone", 60),
  makeTreatment("MASSAGE & THERAPY", "30 Minutes", "Relaxing", 70),
  makeTreatment("MASSAGE & THERAPY", "30 Minutes", "Couple", 80),
  makeTreatment("MASSAGE & THERAPY", "60 Minutes", "Massage", 70),
  makeTreatment("MASSAGE & THERAPY", "60 Minutes", "Aroma", 60),
  makeTreatment("MASSAGE & THERAPY", "60 Minutes", "Hot Stone", 80),
  makeTreatment("MASSAGE & THERAPY", "60 Minutes", "Relaxing", 100),
  makeTreatment("MASSAGE & THERAPY", "60 Minutes", "Couple", 110),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "3 Areas", 260),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "Nefertiti Neck Lift", 260),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "Jaw Relaxing/Slimming", 260),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "Trapezius", 320),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "Additional Areas", 60),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "Anti-Sweating Hands/Underarms", 360),
  makeTreatment("ADVANCED AESTHETICS", "Anti-Wrinkle Treatment", "Migraine Prevention", 480),
  makeTreatment("ADVANCED AESTHETICS", "Dermal Fillers", "Lip Augmentation", 190),
  makeTreatment("ADVANCED AESTHETICS", "Dermal Fillers", "Temples", 270),
  makeTreatment("ADVANCED AESTHETICS", "Dermal Fillers", "8 Point Face Lift", 660),
  makeTreatment("ADVANCED AESTHETICS", "Dermal Fillers", "Tear Trough Eye Area", 260),
  makeTreatment("ADVANCED AESTHETICS", "Dermal Fillers", "Cheeks Jaw Line Chin", 240),
  makeTreatment("ADVANCED AESTHETICS", "Dermal Fillers", "Rhinoplasty", 270),
  makeTreatment("ADVANCED AESTHETICS", "Advanced Fat Dissolving", "Small Area", 160),
  makeTreatment("ADVANCED AESTHETICS", "Advanced Fat Dissolving", "Large Area", 260),
  makeTreatment("ADVANCED AESTHETICS", "Advanced Fat Dissolving", "3 Sessions Small Area", 360),
  makeTreatment("ADVANCED AESTHETICS", "Advanced Fat Dissolving", "3 Sessions Large Area", 600),
  makeTreatment("ADVANCED AESTHETICS", "PRP / RPF / Exosomes", "1 Session", 260),
  makeTreatment("ADVANCED AESTHETICS", "PRP / RPF / Exosomes", "4 Sessions", 800),
  makeTreatment("ADVANCED AESTHETICS", "PRP / RPF / Exosomes", "6 Sessions", 1100),
  makeTreatment("ADVANCED AESTHETICS", "Vitamin Injections", "Vitamin B12", 40),
  makeTreatment("ADVANCED AESTHETICS", "Vitamin Injections", "Vitamin D", 60),
  makeTreatment("ADVANCED AESTHETICS", "Vitamin Injections", "Vitamin C", 60),
  makeTreatment("ADVANCED AESTHETICS", "Vitamin Injections", "Glutathione", 150),
  makeTreatment("ADVANCED AESTHETICS", "Vitamin Injections", "Biotin", 60),
  makeTreatment("ADVANCED AESTHETICS", "Skin Booster Injections", "Eyes/Face/Neck/Décolletage 1 Session", 260),
  makeTreatment("ADVANCED AESTHETICS", "Skin Booster Injections", "Eyes/Face/Neck/Décolletage 3 Sessions", 630),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "Total Hydration", 180),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "Detox", 180),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "Wellness Plus", 180),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "Advanced Anti-Ageing", 220),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "Skin Lightening & Brightening", 220),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "Methylene Blue", 320),
  makeTreatment("ADVANCED AESTHETICS", "IV Drips", "NAD+", 390),
  makeTreatment("ADVANCED AESTHETICS", "Skin Boosters", "Profhilo", 260),
  makeTreatment("ADVANCED AESTHETICS", "Skin Boosters", "Sunekos", 260),
  makeTreatment("ADVANCED AESTHETICS", "Skin Boosters", "Jalupro", 240),
  makeTreatment("ADVANCED AESTHETICS", "Skin Boosters", "NCTF", 180),
  makeTreatment("ADVANCED AESTHETICS", "Combination Treatments", "Skin Booster & Polynucleotides 1 Session", 250),
  makeTreatment("ADVANCED AESTHETICS", "Combination Treatments", "Skin Booster & Polynucleotides 3 Sessions", 600),
  makeTreatment("ADVANCED AESTHETICS", "Combination Treatments", "Lip Filler & Lip Flip", 250),
  makeTreatment("ADVANCED AESTHETICS", "Combination Treatments", "3 Areas Botox & Skin Booster", 399),
  makeTreatment("ADVANCED AESTHETICS", "Combination Treatments", "NCTF Eye Brightening 1 Session", 250),
  makeTreatment("ADVANCED AESTHETICS", "Combination Treatments", "NCTF Eye Brightening 3 Sessions", 600),
  makeTreatment("ADVANCED AESTHETICS", "Biostimulators", "Radiesse", 400),
  makeTreatment("ADVANCED AESTHETICS", "Biostimulators", "Aculptra", 380)
];

const defaultState = () => ({
  catalogueVersion: CATALOGUE_VERSION,
  launchDataVersion: LAUNCH_DATA_VERSION,
  currentView: "dashboard",
  currentRole: "Admin",
  selectedDate: todayISO(),
  financeUnlockedUntil: 0,
  extraHoursByDate: {},
  staff: [],
  customers: [],
  treatments: treatmentCatalogue(),
  appointments: []
});

let state = load();
let modal = null;

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!saved) return defaultState();
    const defaults = defaultState();
    const launchCleaned = saved.launchDataVersion === LAUNCH_DATA_VERSION ? saved : removeSampleData(saved);
    const hasLegacyTreatments = saved.treatments?.some((t) => !t.subcategory);
    const hasOutdatedCatalogue = saved.catalogueVersion !== CATALOGUE_VERSION || !saved.treatments?.some((t) => t.category === "ADVANCED AESTHETICS" && t.subcategory === "Anti-Wrinkle Treatment") || saved.treatments?.some((t) => ["ANTI-WRINKLE TREATMENTS", "DERMAL FILLERS", "IV DRIPS", "PRP", "PRP / RPF / EXOSOMES", "FAT REDUCTION & BODY CONTOURING", "MASSAGE / THERAPY"].includes(t.category));
    const treatments = hasLegacyTreatments || hasOutdatedCatalogue ? treatmentCatalogue() : launchCleaned.treatments || defaults.treatments;
    const legacyTreatmentIds = {
      t1: "trt-facials-hydrafacial-silver",
      t2: "trt-advanced-aesthetics-prp-rpf-exosomes-1-session",
      t3: "trt-facials-laser-carbon-peel-face",
      t4: "trt-laser-hair-removal-general-full-body",
      t5: "trt-advanced-aesthetics-anti-wrinkle-treatment-3-areas",
      "trt-prp-prp-single-session-face-prp": "trt-advanced-aesthetics-prp-rpf-exosomes-1-session",
      "trt-prp-prp-single-session-hair-prp": "trt-advanced-aesthetics-prp-rpf-exosomes-1-session",
      "trt-prp-prp-single-session-lip-prp": "trt-advanced-aesthetics-prp-rpf-exosomes-1-session",
      "trt-prp-prp-combination-prp-microneedling": "trt-advanced-aesthetics-combination-treatments-skin-booster-polynucleotides-1-session",
      "trt-advanced-aesthetics-general-anti-wrinkle-treatment": "trt-advanced-aesthetics-anti-wrinkle-treatment-3-areas",
      "trt-advanced-aesthetics-general-dermal-fillers": "trt-advanced-aesthetics-dermal-fillers-lip-augmentation",
      "trt-advanced-aesthetics-general-iv-drips": "trt-advanced-aesthetics-iv-drips-total-hydration",
      "trt-advanced-aesthetics-general-skin-boosters": "trt-advanced-aesthetics-skin-boosters-profhilo",
      "trt-advanced-aesthetics-general-vitamin-injections": "trt-advanced-aesthetics-vitamin-injections-vitamin-b12",
      "trt-advanced-aesthetics-general-biostimulators": "trt-advanced-aesthetics-biostimulators-radiesse",
      "trt-anti-wrinkle-treatments-general-3-areas": "trt-advanced-aesthetics-anti-wrinkle-treatment-3-areas",
      "trt-dermal-fillers-general-lip-augmentation": "trt-advanced-aesthetics-dermal-fillers-lip-augmentation",
      "trt-iv-drips-general-total-hydration": "trt-advanced-aesthetics-iv-drips-total-hydration",
      "trt-prp-rpf-exosomes-general-1-session": "trt-advanced-aesthetics-prp-rpf-exosomes-1-session",
      "trt-vitamin-injections-general-vitamin-b12": "trt-advanced-aesthetics-vitamin-injections-vitamin-b12",
      "trt-biostimulators-general-radiesse": "trt-advanced-aesthetics-biostimulators-radiesse"
    };
    const appointments = (launchCleaned.appointments || defaults.appointments).map((appt) => ({
      ...appt,
      treatments: (appt.treatments || []).map((line) => ({ ...line, treatmentId: legacyTreatmentIds[line.treatmentId] || line.treatmentId }))
    }));
    return { ...defaults, ...launchCleaned, catalogueVersion: CATALOGUE_VERSION, launchDataVersion: LAUNCH_DATA_VERSION, treatments, appointments };
  } catch {
    return defaultState();
  }
}

function removeSampleData(saved) {
  const sampleClientIds = new Set(["c1", "c2", "c3"]);
  const sampleStaffIds = new Set(["s1", "s2", "s3"]);
  const sampleAppointmentIds = new Set(["a1", "a2", "a3", "a4"]);
  const customers = (saved.customers || []).filter((client) => !sampleClientIds.has(client.id));
  const staff = (saved.staff || []).filter((member) => !sampleStaffIds.has(member.id));
  const appointments = (saved.appointments || []).filter((appt) => (
    !sampleAppointmentIds.has(appt.id) &&
    !sampleClientIds.has(appt.customerId) &&
    !sampleStaffIds.has(appt.staffId)
  ));
  return { ...saved, customers, staff, appointments, launchDataVersion: LAUNCH_DATA_VERSION };
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function toast(message) {
  const el = document.getElementById("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("show"), 2300);
}

function isFinanceUnlocked() {
  return state.currentRole === "Admin" && Date.now() < Number(state.financeUnlockedUntil || 0);
}

function appointmentCustomer(appt) {
  return state.customers.find((c) => c.id === appt.customerId) || { fullName: "Unknown client", phone: "" };
}

function appointmentStaff(appt) {
  return state.staff.find((s) => s.id === appt.staffId) || { name: "Unassigned" };
}

function treatmentName(id) {
  const treatment = state.treatments.find((t) => t.id === id);
  return treatment ? `${treatment.subcategory === "General" ? "" : `${treatment.subcategory} `}${treatment.name}`.trim() : "Treatment";
}

function treatmentSearchText(treatment) {
  const display = treatmentDisplayParts(treatment);
  return normalize(`${treatment.category} ${display.treatment} ${display.variant} ${treatmentLabel(treatment)}`);
}

function treatmentByPickerLabel(label) {
  return state.treatments.find((t) => treatmentPickerLabel(t) === label || treatmentLabel(t) === label);
}

function appointmentTreatmentLabel(appt) {
  return (appt.treatments || []).map((line) => treatmentName(line.treatmentId)).join(" + ") || "No treatments";
}

function activeAppointmentsForDate(date) {
  return state.appointments.filter((a) => a.date === date && a.status !== "Cancelled");
}

function extraHoursForDate(date = state.selectedDate) {
  return [...new Set(state.extraHoursByDate?.[date] || [])].map(Number).sort((a, b) => a - b);
}

function calendarHourStarts(date = state.selectedDate) {
  const defaultHours = Array.from({ length: 10 }, (_, i) => CLINIC_START + i * 60);
  return [...defaultHours, ...extraHoursForDate(date).map((hour) => hour * 60)];
}

function calendarVisibleEnd(date = state.selectedDate) {
  const hours = calendarHourStarts(date);
  return Math.max(...hours) + 60;
}

function calendarHeight(date = state.selectedDate) {
  return ((calendarVisibleEnd(date) - CLINIC_START) / 60) * HOUR_HEIGHT;
}

function appointmentEndTime(appt) {
  return minutesToTime(timeToMinutes(appt.time) + Number(appt.duration || 0));
}

function hasOverlap(candidate, ignoreId = null) {
  if (candidate.status === "Cancelled") return null;
  const start = timeToMinutes(candidate.time);
  const end = start + Number(candidate.duration || 0);
  return activeAppointmentsForDate(candidate.date).find((appt) => {
    if (appt.id === ignoreId || appt.staffId !== candidate.staffId || appt.status === "Cancelled") return false;
    const otherStart = timeToMinutes(appt.time);
    const otherEnd = otherStart + Number(appt.duration || 0);
    return start < otherEnd && end > otherStart;
  });
}

function render() {
  save();
  document.body.classList.remove("nav-open");
  document.getElementById("app").innerHTML = `
    <div class="app-shell">
      ${sidebar()}
      <main class="main">
        ${topbar()}
        <section class="page">${view()}</section>
      </main>
    </div>
    ${modal ? modalMarkup() : ""}
  `;
  bindGlobal();
  bindView();
  if (modal) bindModal();
}

function sidebar() {
  const nav = [
    ["dashboard", "Dashboard"],
    ["appointments", "Appointments"],
    ["customers", "Clients"],
    ["treatments", "Treatments"],
    ["staff", "Staff"],
    ["reports", "Reports"],
    ["settings", "Settings"]
  ];
  return `
    <aside class="sidebar">
      <div class="brand">
        <div class="mark">LT</div>
        <div><div class="brand-title">Laser Treat</div><div class="brand-sub">Esthetica</div></div>
      </div>
      <nav class="nav">
        ${nav.map(([id, label]) => `<button class="${state.currentView === id ? "active" : ""}" data-nav="${id}">${label}</button>`).join("")}
      </nav>
      <div class="user-card">
        <div class="avatar">${state.currentRole.slice(0, 2).toUpperCase()}</div>
        <div><div class="item-title">${state.currentRole} User</div><div class="item-meta">${state.currentRole}</div></div>
        <select class="role-switch" id="roleSwitch">
          <option ${state.currentRole === "Admin" ? "selected" : ""}>Admin</option>
          <option ${state.currentRole === "Staff" ? "selected" : ""}>Staff</option>
        </select>
      </div>
    </aside>
  `;
}

function topbar() {
  return `
    <header class="topbar">
      <div class="actions">
        <button class="icon-btn mobile-menu" id="menuBtn" aria-label="Open navigation">Menu</button>
        <strong>${pageTitle()}</strong>
      </div>
      <div class="actions">
        <button class="btn gold small" data-open-appointment>New Appointment</button>
      </div>
    </header>
  `;
}

function pageTitle() {
  return ({ dashboard: "Dashboard", appointments: "Appointments", customers: "Clients", treatments: "Treatments", staff: "Staff", reports: "Reports", settings: "Settings" })[state.currentView];
}

function view() {
  if (state.currentView === "dashboard") return dashboardView();
  if (state.currentView === "appointments") return appointmentsView();
  if (state.currentView === "customers") return customersView();
  if (state.currentView === "treatments") return treatmentsView();
  if (state.currentView === "staff") return staffView();
  if (state.currentView === "reports") return reportsView();
  return settingsView();
}

function dashboardStats() {
  const today = todayISO();
  const todaysAppointments = state.appointments.filter((a) => a.date === today && a.status === "Scheduled").length;
  const pendingPayments = state.appointments.filter((a) => ["Unpaid", "Deposit Paid"].includes(a.paidStatus) && a.status !== "Cancelled").length;
  return { todaysAppointments, pendingPayments };
}

function dashboardView() {
  const stats = dashboardStats();
  const nowDate = todayISO();
  const upcomingAppointments = state.appointments
    .filter((a) => a.status === "Scheduled" && (a.date > nowDate || a.date === nowDate))
    .sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`))
    .slice(0, 6);
  const recentClients = [...state.customers].slice(-6).reverse();
  return `
    <div class="page-head">
      <div><h1>Dashboard</h1><p class="subtitle">Launch-ready clinic operations with no sample data.</p></div>
    </div>
    <div class="grid stats">
      ${stat("Today's Appointments", stats.todaysAppointments, "Scheduled bookings only")}
      ${stat("Active Staff", state.staff.filter((s) => s.active).length, "Available team members")}
      ${stat("Total Clients", state.customers.length, "Saved client records")}
      ${stat("Pending Payments", stats.pendingPayments, "Unpaid or deposit paid")}
    </div>
    <div class="grid dashboard-panels">
      <div class="card">
        <div class="section-title"><h2>Upcoming Appointments</h2><button class="btn ghost small" data-nav="appointments">View Calendar</button></div>
        <div class="list">
          ${upcomingAppointments.length ? upcomingAppointments.map(scheduleRow).join("") : `<div class="empty">No upcoming appointments.</div>`}
        </div>
      </div>
      <div class="card">
        <div class="section-title"><h2>Recent Clients</h2><button class="btn ghost small" data-nav="customers">View Clients</button></div>
        <div class="list">
          ${recentClients.length ? recentClients.map((client) => `<div class="row-item"><div><div class="item-title">${client.fullName}</div><div class="item-meta">${client.phone || "No phone"}${client.email ? ` · ${client.email}` : ""}</div></div><span class="badge gold">Client</span></div>`).join("") : `<div class="empty">No clients yet.</div>`}
        </div>
      </div>
    </div>
  `;
}

function stat(label, value, foot) {
  return `<div class="stat"><div class="stat-label">${label}</div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></div>`;
}

function scheduleRow(appt) {
  return `
    <div class="row-item">
      <div class="item-main">
        <div class="item-title">${appt.date} · ${niceTime(appt.time)} - ${appointmentCustomer(appt).fullName}</div>
        <div class="item-meta">${appointmentTreatmentLabel(appt)} with ${appointmentStaff(appt).name}</div>
      </div>
      <span class="badge ${appt.status === "Cancelled" ? "red" : appt.status === "Completed" ? "gray" : "green"}">${appt.status}</span>
    </div>
  `;
}

function appointmentsView() {
  const staffFilter = sessionStorage.getItem("staffFilter") || "";
  const statusFilter = sessionStorage.getItem("statusFilter") || "";
  const staffOptions = state.staff.map((s) => `<option value="${s.id}" ${staffFilter === s.id ? "selected" : ""}>${s.name}</option>`).join("");
  const hourStarts = calendarHourStarts();
  const extraHours = extraHoursForDate();
  return `
    <div class="page-head">
      <div><h1>Appointments</h1><p class="subtitle">1-hour visual rows from 11:00 AM to 8:00 PM. Actual appointment times can still be exact.</p></div>
      <button class="btn gold" data-open-appointment>New Appointment</button>
    </div>
    <div class="toolbar">
      <input type="date" id="calendarDate" value="${state.selectedDate}">
      <select id="staffFilter"><option value="">All Staff</option>${staffOptions}</select>
      <select id="statusFilter"><option value="">All Statuses</option><option ${statusFilter === "Scheduled" ? "selected" : ""}>Scheduled</option><option ${statusFilter === "Completed" ? "selected" : ""}>Completed</option><option ${statusFilter === "Cancelled" ? "selected" : ""}>Cancelled</option></select>
      <button class="btn ghost small" id="addExtraHour">+ Add Extra Hour</button>
    </div>
    ${extraHours.length ? `<div class="extra-hours">${extraHours.map((hour) => `<span class="badge gold">${niceTime(minutesToTime(hour * 60))}<button type="button" data-remove-extra-hour="${hour}" aria-label="Remove ${niceTime(minutesToTime(hour * 60))}">x</button></span>`).join("")}</div>` : ""}
    <div class="calendar" style="min-height:${calendarHeight()}px">
      <div class="times">${hourStarts.map((minutes) => `<div class="time-label">${niceTime(minutesToTime(minutes))}</div>`).join("")}</div>
      <div class="slots">
        <div class="slot-lines"></div>
        ${openSlotButtons()}
        ${appointmentCards()}
      </div>
    </div>
  `;
}

function filteredAppointments() {
  const staffFilter = sessionStorage.getItem("staffFilter") || "";
  const statusFilter = sessionStorage.getItem("statusFilter") || "";
  return state.appointments
    .filter((a) => a.date === state.selectedDate)
    .filter((a) => !staffFilter || a.staffId === staffFilter)
    .filter((a) => !statusFilter || a.status === statusFilter)
    .sort((a, b) => a.time.localeCompare(b.time));
}

function openSlotButtons() {
  return calendarHourStarts().map((minutes) => {
    const top = ((minutes - CLINIC_START) / 60) * HOUR_HEIGHT;
    const time = minutesToTime(minutes);
    return `<button class="open-slot" style="top:${top}px" data-slot-time="${time}">+ Add appointment</button>`;
  }).join("");
}

function addExtraHour() {
  const date = state.selectedDate;
  const currentLastHour = Math.max(...calendarHourStarts(date)) / 60;
  const nextHour = currentLastHour + 1;
  state.extraHoursByDate = state.extraHoursByDate || {};
  state.extraHoursByDate[date] = [...new Set([...(state.extraHoursByDate[date] || []), nextHour])].sort((a, b) => a - b);
  toast(`Added ${niceTime(minutesToTime(nextHour * 60))}`);
  render();
}

function removeExtraHour(hour) {
  const date = state.selectedDate;
  const hourStart = hour * 60;
  const hasAppointments = state.appointments.some((appt) => appt.date === date && timeToMinutes(appt.time) >= hourStart && timeToMinutes(appt.time) < hourStart + 60);
  if (hasAppointments) return toast("Cannot remove an extra hour with appointments.");
  state.extraHoursByDate = state.extraHoursByDate || {};
  state.extraHoursByDate[date] = (state.extraHoursByDate[date] || []).filter((savedHour) => Number(savedHour) !== Number(hour));
  toast(`Removed ${niceTime(minutesToTime(hour * 60))}`);
  render();
}

function appointmentCards() {
  const staffIds = [...new Set(filteredAppointments().map((a) => a.staffId))];
  const count = Math.max(1, staffIds.length);
  return filteredAppointments().map((appt) => {
    const top = ((timeToMinutes(appt.time) - CLINIC_START) / 60) * HOUR_HEIGHT;
    const height = Math.max(38, (Number(appt.duration) / 60) * HOUR_HEIGHT - 4);
    const index = staffIds.indexOf(appt.staffId);
    const width = `calc(${100 / count}% - 16px)`;
    const left = `calc(${index * (100 / count)}% + 10px)`;
    const cls = ["appointment-card", appt.status.toLowerCase(), appt.override ? "override" : ""].join(" ");
    return `
      <button class="${cls}" style="top:${top}px;height:${height}px;left:${left};width:${width}" data-edit-appointment="${appt.id}">
        <strong>${appointmentCustomer(appt).fullName}</strong>
        <span>${niceTime(appt.time)} - ${niceTime(appointmentEndTime(appt))}</span>
        <span>${appointmentTreatmentLabel(appt)}</span>
        <span>${appointmentStaff(appt).name}</span>
        <div class="card-badges">
          <em class="badge ${appt.status === "Cancelled" ? "red" : appt.status === "Completed" ? "gray" : "green"}">${appt.status}</em>
          ${appt.override ? `<em class="badge gold">Override</em>` : ""}
        </div>
      </button>
    `;
  }).join("");
}

function customersView() {
  return `
    <div class="page-head">
      <div><h1>Clients</h1><p class="subtitle">Search by name or phone. Clients with appointments cannot be deleted.</p></div>
      <button class="btn gold" data-open-customer>Add Client</button>
    </div>
    <div class="toolbar"><input id="customerSearch" placeholder="Search clients" value="${sessionStorage.getItem("customerSearch") || ""}"></div>
    <div class="card table-wrap"><table class="table">
      <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>DOB</th><th>Appointments</th><th></th></tr></thead>
      <tbody>${visibleCustomers().map(customerRow).join("") || `<tr><td colspan="6">No matching clients.</td></tr>`}</tbody>
    </table></div>
  `;
}

function visibleCustomers() {
  const query = normalize(sessionStorage.getItem("customerSearch") || "");
  return state.customers.filter((c) => !query || normalize(`${c.fullName} ${c.phone}`).includes(query));
}

function customerRow(customer) {
  const apptCount = state.appointments.filter((a) => a.customerId === customer.id).length;
  return `<tr>
    <td><strong>${customer.fullName}</strong><div class="item-meta">${customer.notes || "No notes"}</div></td>
    <td>${customer.phone}</td><td>${customer.email || "-"}</td><td>${customer.dob || "-"}</td><td>${apptCount}</td>
    <td class="actions"><button class="btn ghost small" data-open-customer="${customer.id}">Edit</button><button class="btn danger small" data-delete-customer="${customer.id}">Delete</button></td>
  </tr>`;
}

function treatmentsView() {
  const treatmentCount = state.treatments.length;
  const grouped = treatmentsByCategory();
  return `
    <div class="page-head">
      <div><h1>Treatments</h1><p class="subtitle">${treatmentCount} treatments across categories and subcategories. Admins can add, edit, and remove catalogue items.</p></div>
      ${state.currentRole === "Admin" ? `<button class="btn gold" data-open-treatment>Add Treatment</button>` : ""}
    </div>
    <div class="treatment-catalogue">
      ${grouped.map(treatmentCategorySection).join("")}
    </div>
  `;
}

function treatmentsByCategory() {
  const groups = new Map();
  state.treatments.forEach((treatment) => {
    if (!groups.has(treatment.category)) groups.set(treatment.category, []);
    groups.get(treatment.category).push(treatment);
  });
  return [...groups.entries()].map(([category, treatments]) => ({
    category,
    treatments
  }));
}

function treatmentCategorySection(group) {
  const collapsed = (sessionStorage.getItem("collapsedTreatmentCategories") || "").split("|").includes(group.category);
  return `
    <section class="treatment-section ${collapsed ? "collapsed" : ""}">
      <button class="treatment-section-head" data-toggle-treatment-category="${group.category}" aria-expanded="${!collapsed}">
        <span class="treatment-chevron">${collapsed ? ">" : "v"}</span>
        <span>${group.category}</span>
        <em>${group.treatments.length} treatments</em>
      </button>
      <div class="table-wrap treatment-table-wrap ${collapsed ? "hidden" : ""}">
        <table class="table treatment-table">
          <thead><tr><th>Category</th><th>Treatment</th><th>Variant</th><th>Duration</th><th>Price</th><th>Actions</th></tr></thead>
          <tbody>${group.treatments.map(treatmentRow).join("")}</tbody>
        </table>
      </div>
    </section>
  `;
}

function treatmentDisplayParts(treatment) {
  const isGeneral = !treatment.subcategory || treatment.subcategory === "General";
  return {
    treatment: isGeneral ? treatment.name : treatment.subcategory,
    variant: isGeneral ? "Standard" : treatment.name
  };
}

function treatmentRow(treatment) {
  const used = state.appointments.some((appt) => (appt.treatments || []).some((line) => line.treatmentId === treatment.id));
  const display = treatmentDisplayParts(treatment);
  return `<tr>
    <td>${treatment.category}</td>
    <td><strong>${display.treatment}</strong></td>
    <td>${display.variant}</td>
    <td class="duration-cell">${treatment.duration} min</td>
    <td class="price-cell">${money(treatment.defaultPrice)}</td>
    <td>
      <div class="treatment-actions">
        ${state.currentRole === "Admin" ? `<button class="btn ghost small" data-open-treatment="${treatment.id}">Edit</button><button class="btn danger small" data-delete-treatment="${treatment.id}" ${used ? "disabled" : ""}>Remove</button>` : `<span class="badge gray">View only</span>`}
      </div>
    </td>
  </tr>`;
}

function staffView() {
  return `
    <div class="page-head">
      <div><h1>Staff</h1><p class="subtitle">Assign team members, roles, and availability.</p></div>
      <button class="btn gold" data-open-staff>Add Staff</button>
    </div>
    <div class="grid">${state.staff.length ? state.staff.map((s) => `
      <div class="card row-item">
        <div><div class="item-title">${s.name}</div><div class="item-meta">${s.role} · ${s.availability}</div></div>
        <div class="actions"><span class="badge ${s.active ? "green" : "gray"}">${s.active ? "Active" : "Inactive"}</span><button class="btn ghost small" data-open-staff="${s.id}">Edit</button><button class="btn danger small" data-delete-staff="${s.id}">Delete</button></div>
      </div>`).join("") : `<div class="empty">No staff added yet. Add your first practitioner to start booking appointments.</div>`}</div>
  `;
}

function reportsView() {
  if (state.currentRole !== "Admin") return lockedMessage("Reports are available to Admin users only.");
  if (!isFinanceUnlocked()) return pinView("Unlock Finance Reports");
  const month = todayISO().slice(0, 7);
  const monthAppointments = state.appointments.filter((a) => a.date.startsWith(month));
  const paid = monthAppointments.filter((a) => a.paidStatus === "Paid");
  const revenue = paid.reduce((sum, a) => sum + Number(a.finalPrice || 0), 0);
  const deposits = monthAppointments.reduce((sum, a) => sum + Number(a.deposit || 0), 0);
  const vouchers = monthAppointments.filter((a) => a.voucherSource && a.voucherSource !== "None").length;
  const top = topTreatments(monthAppointments);
  return `
    <div class="page-head"><div><h1>Reports</h1><p class="subtitle">Finance uses final price and includes paid appointments only.</p></div></div>
    <div class="grid stats">
      ${stat("Monthly Revenue", money(revenue), "Paid appointments")}
      ${stat("Deposits", money(deposits), "All statuses")}
      ${stat("Voucher Usage", vouchers, "Wowcher, Groupon, Other")}
      ${stat("Appointment Count", monthAppointments.length, "This month")}
    </div>
    <div class="card" style="margin-top:14px">
      <div class="section-title"><h2>Top Treatments</h2><span class="badge gold">${month}</span></div>
      <div class="list">${top.map(([name, count]) => `<div class="row-item"><div class="item-title">${name}</div><span class="badge">${count}</span></div>`).join("") || `<div class="empty">No treatment activity this month.</div>`}</div>
    </div>
  `;
}

function topTreatments(appointments) {
  const counts = {};
  appointments.forEach((appt) => (appt.treatments || []).forEach((line) => counts[treatmentName(line.treatmentId)] = (counts[treatmentName(line.treatmentId)] || 0) + 1));
  return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 5);
}

function settingsView() {
  return `
    <div class="page-head"><div><h1>Settings</h1><p class="subtitle">Security and operational controls.</p></div></div>
    <div class="card">
      <h2>Finance PIN Lock</h2>
      <p class="subtitle">Finance pages require Admin role and a 4-6 digit PIN. Demo PIN: 2468. Unlock lasts 10 minutes.</p>
      <div class="actions" style="margin-top:12px">
        <button class="btn gold" data-unlock-finance>Unlock Finance</button>
        <button class="btn ghost" id="lockFinance">Lock Now</button>
      </div>
    </div>
  `;
}

function lockedMessage(message) {
  return `<div class="card"><h1>Access restricted</h1><p class="subtitle">${message}</p></div>`;
}

function pinView(title) {
  return `<div class="lock-screen" style="min-height:50vh"><div class="login-card"><div class="login-logo"><div class="mark">LT</div><h1>${title}</h1><p class="subtitle">Enter the 4-6 digit finance PIN.</p></div><label>Finance PIN<input id="pinInput" type="password" inputmode="numeric" maxlength="6" placeholder="2468"></label><button class="btn gold" id="pinBtn" style="margin-top:12px">Unlock for 10 Minutes</button></div></div>`;
}

function bindGlobal() {
  document.querySelectorAll("[data-nav]").forEach((btn) => btn.addEventListener("click", () => {
    state.currentView = btn.dataset.nav;
    render();
  }));
  document.querySelectorAll("[data-open-appointment]").forEach((btn) => btn.addEventListener("click", () => openAppointment({ date: state.selectedDate })));
  document.getElementById("menuBtn")?.addEventListener("click", () => document.body.classList.add("nav-open"));
  document.getElementById("roleSwitch")?.addEventListener("change", (e) => {
    state.currentRole = e.target.value;
    if (state.currentRole !== "Admin") state.financeUnlockedUntil = 0;
    render();
  });
}

function bindView() {
  document.getElementById("calendarDate")?.addEventListener("change", (e) => { state.selectedDate = e.target.value; render(); });
  document.getElementById("staffFilter")?.addEventListener("change", (e) => { sessionStorage.setItem("staffFilter", e.target.value); render(); });
  document.getElementById("statusFilter")?.addEventListener("change", (e) => { sessionStorage.setItem("statusFilter", e.target.value); render(); });
  document.getElementById("addExtraHour")?.addEventListener("click", addExtraHour);
  document.querySelectorAll("[data-remove-extra-hour]").forEach((btn) => btn.addEventListener("click", () => removeExtraHour(Number(btn.dataset.removeExtraHour))));
  document.querySelectorAll("[data-slot-time]").forEach((btn) => btn.addEventListener("click", () => openAppointment({ date: state.selectedDate, time: btn.dataset.slotTime })));
  document.querySelectorAll("[data-edit-appointment]").forEach((btn) => btn.addEventListener("click", () => openAppointment(state.appointments.find((a) => a.id === btn.dataset.editAppointment))));
  document.getElementById("customerSearch")?.addEventListener("input", (e) => { sessionStorage.setItem("customerSearch", e.target.value); render(); });
  document.querySelectorAll("[data-open-customer]").forEach((btn) => btn.addEventListener("click", () => openCustomer(btn.dataset.openCustomer || null)));
  document.querySelectorAll("[data-delete-customer]").forEach((btn) => btn.addEventListener("click", () => deleteCustomer(btn.dataset.deleteCustomer)));
  document.querySelectorAll("[data-open-treatment]").forEach((btn) => btn.addEventListener("click", () => openTreatment(btn.dataset.openTreatment || null)));
  document.querySelectorAll("[data-delete-treatment]").forEach((btn) => btn.addEventListener("click", () => deleteTreatment(btn.dataset.deleteTreatment)));
  document.querySelectorAll("[data-toggle-treatment-category]").forEach((btn) => btn.addEventListener("click", () => toggleTreatmentCategory(btn.dataset.toggleTreatmentCategory)));
  document.querySelectorAll("[data-open-staff]").forEach((btn) => btn.addEventListener("click", () => openStaff(btn.dataset.openStaff || null)));
  document.querySelectorAll("[data-delete-staff]").forEach((btn) => btn.addEventListener("click", () => deleteStaff(btn.dataset.deleteStaff)));
  document.querySelectorAll("[data-unlock-finance]").forEach((btn) => btn.addEventListener("click", () => { state.currentView = "reports"; render(); }));
  document.getElementById("lockFinance")?.addEventListener("click", () => { state.financeUnlockedUntil = 0; toast("Finance locked"); render(); });
  document.getElementById("pinBtn")?.addEventListener("click", unlockFinance);
  document.getElementById("pinInput")?.addEventListener("keydown", (e) => { if (e.key === "Enter") unlockFinance(); });
}

function unlockFinance() {
  const pin = document.getElementById("pinInput")?.value || "";
  if (!/^\d{4,6}$/.test(pin) || pin !== FINANCE_PIN) return toast("Invalid finance PIN");
  state.financeUnlockedUntil = Date.now() + 10 * 60 * 1000;
  toast("Finance unlocked");
  render();
}

function openAppointment(appt = {}) {
  const existing = appt.id ? appt : null;
  modal = {
    type: "appointment",
    data: JSON.parse(JSON.stringify(existing || {
      id: null, date: appt.date || state.selectedDate, time: appt.time || "11:00", duration: 30,
      staffId: state.staff[0]?.id, customerId: "", status: "Scheduled",
      treatmentPlanNotes: "", treatments: [{ treatmentId: state.treatments[0]?.id, duration: state.treatments[0]?.duration || 30, price: state.treatments[0]?.defaultPrice || 0, staffId: state.staff[0]?.id }],
      basePrice: state.treatments[0]?.defaultPrice || 0, priceOverride: null, finalPrice: state.treatments[0]?.defaultPrice || 0,
      deposit: 0, paidStatus: "Unpaid", voucherSource: "None", voucherCode: "", paymentMethod: "Card", override: false, notes: ""
    })),
    customerQuery: existing ? appointmentCustomer(existing).fullName : "",
    treatmentQueries: {},
    activeTreatmentPicker: null,
    conflict: null
  };
  recalcAppointmentFinance(false);
  render();
}

function modalMarkup() {
  if (modal.type === "appointment") return appointmentModal();
  if (modal.type === "customer") return customerModal();
  if (modal.type === "treatment") return treatmentModal();
  if (modal.type === "staff") return staffModal();
  return "";
}

function appointmentModal() {
  const a = modal.data;
  const staffOptions = state.staff.length
    ? state.staff.map((s) => `<option value="${s.id}" ${a.staffId === s.id ? "selected" : ""}>${s.name}</option>`).join("")
    : `<option value="">Add staff first</option>`;
  return `
    <div class="modal-backdrop"><form class="modal" id="appointmentForm">
      <div class="modal-head"><div><h2>${a.id ? "Edit Appointment" : "New Appointment"}</h2><p class="subtitle">Exact time, staff conflict checks, multi-treatment finance.</p></div><button type="button" class="modal-close" data-close aria-label="Close modal"><span aria-hidden="true">&times;</span></button></div>
      <div class="modal-body grid">
        ${modal.conflict ? `<div class="alert">Conflict with ${appointmentCustomer(modal.conflict).fullName} at ${niceTime(modal.conflict.time)} for ${appointmentStaff(modal.conflict).name}. Use Override & Book to save anyway.</div>` : ""}
        <div class="form-grid">
          <label>Date<input name="date" type="date" value="${a.date}" required></label>
          <label>Actual Time<input name="time" type="time" step="60" value="${a.time}" required></label>
          <label>Duration<select name="duration">${durationOptions(a.duration)}</select></label>
          <label>Staff<select name="staffId">${staffOptions}</select></label>
          <label class="full">Client Search
            <div class="search-wrap">
              <input id="bookingCustomerSearch" value="${modal.customerQuery || ""}" placeholder="Type at least 1 character: name or phone" autocomplete="off">
              ${customerSearchResults()}
            </div>
          </label>
          <div class="full actions"><button type="button" class="btn ghost small" id="inlineCustomerBtn">Create New Client</button>${a.customerId ? `<span class="badge green">Selected: ${appointmentCustomer(a).fullName}</span>` : `<span class="badge gold">No client selected</span>`}</div>
          <label>Status<select name="status"><option ${a.status === "Scheduled" ? "selected" : ""}>Scheduled</option><option ${a.status === "Completed" ? "selected" : ""}>Completed</option><option ${a.status === "Cancelled" ? "selected" : ""}>Cancelled</option></select></label>
          <label>Payment Status<select name="paidStatus"><option>Unpaid</option><option ${a.paidStatus === "Deposit Paid" ? "selected" : ""}>Deposit Paid</option><option ${a.paidStatus === "Paid" ? "selected" : ""}>Paid</option><option ${a.paidStatus === "Refunded" ? "selected" : ""}>Refunded</option></select></label>
        </div>
        <div class="card">
          <div class="section-title"><h3>Treatments</h3><button type="button" class="btn ghost small" id="addLine">Add Treatment</button></div>
          <div class="grid">${(a.treatments || []).map((line, index) => lineItemMarkup(line, index)).join("")}</div>
          <div class="finance-summary">${mini("Base Price", money(a.basePrice))}${mini("Final Price", money(a.finalPrice))}${mini("Deposit", money(a.deposit))}${mini("Balance", money(Math.max(0, Number(a.finalPrice || 0) - Number(a.deposit || 0))))}</div>
        </div>
        <div class="form-grid">
          <label class="full">Treatment Plan Notes<textarea name="treatmentPlanNotes">${a.treatmentPlanNotes || ""}</textarea></label>
          <label>Base Price<input name="basePrice" type="number" min="0" step="0.01" value="${a.basePrice || 0}" readonly></label>
          <label>Manual Price Override<input name="priceOverride" type="number" min="0" step="0.01" value="${a.priceOverride ?? ""}" placeholder="Leave blank to use base price"></label>
          <label>Final Price<input name="finalPrice" type="number" min="0" step="0.01" value="${a.finalPrice || 0}" readonly></label>
          <label>Deposit<input name="deposit" type="number" min="0" step="0.01" value="${a.deposit || 0}"></label>
          <label>Voucher Source<select name="voucherSource"><option>None</option><option ${a.voucherSource === "Wowcher" ? "selected" : ""}>Wowcher</option><option ${a.voucherSource === "Groupon" ? "selected" : ""}>Groupon</option><option ${a.voucherSource === "Other" ? "selected" : ""}>Other</option></select></label>
          <label>Voucher Code<input name="voucherCode" value="${a.voucherCode || ""}"></label>
          <label>Payment Method<select name="paymentMethod"><option>Cash</option><option ${a.paymentMethod === "Card" ? "selected" : ""}>Card</option><option ${a.paymentMethod === "Bank Transfer" ? "selected" : ""}>Bank Transfer</option><option ${a.paymentMethod === "Voucher" ? "selected" : ""}>Voucher</option></select></label>
          <label class="full">Appointment Notes<textarea name="notes">${a.notes || ""}</textarea></label>
        </div>
        <div class="actions">
          <button class="btn gold" type="submit">Save Appointment</button>
          ${modal.conflict ? `<button class="btn" type="button" id="overrideBook">Override & Book</button>` : ""}
          <button class="btn ghost" type="button" data-close>Cancel</button>
        </div>
      </div>
    </form></div>
  `;
}

function durationOptions(selected) {
  const values = [5, 15, 30, 45, 60, 90, Number(selected || 0)].filter(Boolean);
  return [...new Set(values)].map((d) => `<option value="${d}" ${Number(selected) === d ? "selected" : ""}>${d} min</option>`).join("");
}

function customerSearchResults() {
  const q = normalize(modal.customerQuery || "");
  if (q.length < 1) return "";
  const matches = state.customers.filter((c) => normalize(`${c.fullName} ${c.phone}`).includes(q)).slice(0, 8);
  if (!matches.length) return `<div class="search-results"><button type="button" disabled>No client found</button></div>`;
  return `<div class="search-results">${matches.map((c) => `<button type="button" data-select-customer="${c.id}"><strong>${c.fullName}</strong><div class="item-meta">${c.phone}</div></button>`).join("")}</div>`;
}

function lineItemMarkup(line, index) {
  const selected = state.treatments.find((t) => t.id === line.treatmentId);
  const query = modal.treatmentQueries?.[index] ?? (selected ? treatmentPickerLabel(selected) : "");
  const staffOptions = state.staff.length
    ? state.staff.map((s) => `<option value="${s.id}" ${(line.staffId || modal.data.staffId) === s.id ? "selected" : ""}>${s.name}</option>`).join("")
    : `<option value="">Add staff first</option>`;
  return `<div class="line-item" data-line="${index}">
    <label class="treatment-picker-label">Treatment
      <div class="treatment-picker-wrap">
        <input data-treatment-search data-line-index="${index}" value="${query}" placeholder="Search hydra, filler, vitamin, laser, prp" autocomplete="off">
        ${treatmentPickerResults(index)}
      </div>
    </label>
    <label>Duration<input data-line-duration type="number" min="5" step="5" value="${line.duration || 0}"></label>
    <label>Therapist<select data-line-staff>${staffOptions}</select></label>
    <label>Price<input data-line-price type="number" min="0" step="0.01" value="${line.price || 0}"></label>
    <button type="button" class="icon-btn" data-remove-line="${index}" aria-label="Remove treatment">X</button>
  </div>`;
}

function treatmentPickerResults(index) {
  if (modal.activeTreatmentPicker !== index) return "";
  const query = normalize(modal.treatmentQueries?.[index] || "");
  const matches = state.treatments.filter((treatment) => !query || treatmentSearchText(treatment).includes(query));
  const grouped = new Map();
  matches.forEach((treatment) => {
    if (!grouped.has(treatment.category)) grouped.set(treatment.category, []);
    grouped.get(treatment.category).push(treatment);
  });
  const body = matches.length ? [...grouped.entries()].map(([category, treatments]) => `
    <div class="treatment-result-group">
      <div class="treatment-result-category">${category}</div>
      ${treatments.map(treatmentPickerOption).join("")}
    </div>
  `).join("") : `<div class="treatment-no-results">No treatments found</div>`;
  return `<div class="treatment-picker-panel">${body}</div>`;
}

function treatmentPickerOption(treatment) {
  const display = treatmentDisplayParts(treatment);
  const title = display.variant === "Standard" ? display.treatment : `${display.treatment} -> ${display.variant}`;
  return `
    <button type="button" class="treatment-result" data-select-treatment="${treatment.id}">
      <span>${title}</span>
      <em>${treatment.duration} min · ${money(treatment.defaultPrice)}</em>
    </button>
  `;
}

function mini(label, value) {
  const key = label.toLowerCase().replace(/\s+/g, "-");
  return `<div class="mini-box"><div class="mini-label">${label}</div><div class="mini-value" data-mini="${key}">${value}</div></div>`;
}

function customerModal() {
  const c = modal.data;
  return `<div class="modal-backdrop"><form class="modal" id="customerForm">
    <div class="modal-head"><h2>${c.id ? "Edit Client" : "Add Client"}</h2><button type="button" class="modal-close" data-close aria-label="Close modal"><span aria-hidden="true">&times;</span></button></div>
    <div class="modal-body form-grid">
      <label>Full Name<input name="fullName" value="${c.fullName || ""}" required></label>
      <label>Phone<input name="phone" value="${c.phone || ""}" required></label>
      <label>Email<input name="email" type="email" value="${c.email || ""}"></label>
      <label>DOB<input name="dob" type="date" value="${c.dob || ""}"></label>
      <label class="full">Notes<textarea name="notes">${c.notes || ""}</textarea></label>
      <label class="full">Medical History<textarea name="medicalHistory">${c.medicalHistory || ""}</textarea></label>
      <div class="full actions"><button class="btn gold" type="submit">Save Client</button><button class="btn ghost" type="button" data-close>Cancel</button></div>
    </div>
  </form></div>`;
}

function treatmentModal() {
  const t = modal.data;
  return `<div class="modal-backdrop"><form class="modal" id="treatmentForm">
    <div class="modal-head"><h2>${t.id ? "Edit Treatment" : "Add Treatment"}</h2><button type="button" class="modal-close" data-close aria-label="Close modal"><span aria-hidden="true">&times;</span></button></div>
    <div class="modal-body form-grid">
      <label>Name<input name="name" value="${t.name || ""}" required></label>
      <label>Category<input name="category" value="${t.category || ""}" required></label>
      <label>Subcategory<input name="subcategory" value="${t.subcategory || "General"}" required></label>
      <label>Duration<input name="duration" type="number" min="5" step="5" value="${t.duration || 30}" required></label>
      <label>Default Price<input name="defaultPrice" type="number" min="0" step="0.01" value="${t.defaultPrice || 0}" required></label>
      <div class="full actions"><button class="btn gold" type="submit">Save Treatment</button><button class="btn ghost" type="button" data-close>Cancel</button></div>
    </div>
  </form></div>`;
}

function staffModal() {
  const s = modal.data;
  return `<div class="modal-backdrop"><form class="modal" id="staffForm">
    <div class="modal-head"><h2>${s.id ? "Edit Staff" : "Add Staff"}</h2><button type="button" class="modal-close" data-close aria-label="Close modal"><span aria-hidden="true">&times;</span></button></div>
    <div class="modal-body form-grid">
      <label>Name<input name="name" value="${s.name || ""}" required></label>
      <label>Role<input name="role" value="${s.role || ""}" required></label>
      <label class="full">Availability<input name="availability" value="${s.availability || "Daily 11:00-20:00"}"></label>
      <label>Active<select name="active"><option value="true" ${s.active !== false ? "selected" : ""}>Active</option><option value="false" ${s.active === false ? "selected" : ""}>Inactive</option></select></label>
      <div class="full actions"><button class="btn gold" type="submit">Save Staff</button><button class="btn ghost" type="button" data-close>Cancel</button></div>
    </div>
  </form></div>`;
}

function openCustomer(id, afterCreate = null) {
  modal = { type: "customer", afterCreate, data: id ? { ...state.customers.find((c) => c.id === id) } : { id: null, fullName: "", phone: "", email: "", dob: "", notes: "", medicalHistory: "" } };
  render();
}

function openTreatment(id) {
  if (state.currentRole !== "Admin") return toast("Admin access required");
  modal = { type: "treatment", data: id ? { ...state.treatments.find((t) => t.id === id) } : { id: null, name: "", category: "", subcategory: "General", duration: 30, defaultPrice: 0 } };
  render();
}

function openStaff(id) {
  modal = { type: "staff", data: id ? { ...state.staff.find((s) => s.id === id) } : { id: null, name: "", role: "", availability: "Daily 11:00-20:00", active: true } };
  render();
}

function bindModal() {
  document.querySelectorAll("[data-close]").forEach((btn) => btn.addEventListener("click", () => { modal = null; render(); }));
  if (modal.type === "appointment") bindAppointmentModal();
  document.getElementById("customerForm")?.addEventListener("submit", saveCustomerForm);
  document.getElementById("treatmentForm")?.addEventListener("submit", saveTreatmentForm);
  document.getElementById("staffForm")?.addEventListener("submit", saveStaffForm);
}

function bindAppointmentModal() {
  const form = document.getElementById("appointmentForm");
  form.addEventListener("input", syncAppointmentFromForm);
  form.addEventListener("change", syncAppointmentFromForm);
  form.addEventListener("submit", (e) => saveAppointmentForm(e, false));
  document.getElementById("overrideBook")?.addEventListener("click", (e) => saveAppointmentForm(e, true));
  document.getElementById("bookingCustomerSearch").addEventListener("input", (e) => {
    modal.customerQuery = e.target.value;
    if (!e.target.value) modal.data.customerId = "";
    render();
  });
  document.querySelectorAll("[data-select-customer]").forEach((btn) => btn.addEventListener("click", () => {
    modal.data.customerId = btn.dataset.selectCustomer;
    modal.customerQuery = appointmentCustomer(modal.data).fullName;
    render();
  }));
  document.getElementById("inlineCustomerBtn").addEventListener("click", () => {
    const appointmentDraft = JSON.parse(JSON.stringify(modal));
    modal = { type: "customer", afterCreate: appointmentDraft, data: { id: null, fullName: modal.customerQuery || "", phone: "", email: "", dob: "", notes: "", medicalHistory: "" } };
    render();
  });
  document.getElementById("addLine").addEventListener("click", () => {
    syncAppointmentFromForm();
    modal.data.treatments.push({ treatmentId: "", duration: 30, price: 0, staffId: modal.data.staffId });
    modal.activeTreatmentPicker = modal.data.treatments.length - 1;
    modal.treatmentQueries[modal.activeTreatmentPicker] = "";
    recalcAppointmentFinance(false);
    render();
  });
  document.querySelectorAll("[data-remove-line]").forEach((btn) => btn.addEventListener("click", () => {
    modal.data.treatments.splice(Number(btn.dataset.removeLine), 1);
    if (!modal.data.treatments.length) modal.data.treatments.push({ treatmentId: state.treatments[0].id, duration: 30, price: 0 });
    recalcAppointmentFinance(false);
    render();
  }));
  document.querySelectorAll("[data-treatment-search]").forEach((input) => {
    const index = Number(input.dataset.lineIndex);
    input.addEventListener("focus", () => {
      if (modal.restoringTreatmentFocus) return;
      syncAppointmentFromForm();
      modal.activeTreatmentPicker = index;
      modal.treatmentQueries[index] = input.value;
      modal.restoreTreatmentFocus = true;
      render();
    });
    input.addEventListener("click", () => {
      syncAppointmentFromForm();
      modal.activeTreatmentPicker = index;
      modal.treatmentQueries[index] = input.value;
      modal.restoreTreatmentFocus = true;
      render();
    });
    input.addEventListener("input", (event) => {
      syncAppointmentFromForm();
      modal.activeTreatmentPicker = index;
      modal.treatmentQueries[index] = event.target.value;
      modal.restoreTreatmentFocus = true;
      render();
    });
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        const query = normalize(modal.treatmentQueries?.[index] || input.value);
        const firstMatch = state.treatments.find((treatment) => !query || treatmentSearchText(treatment).includes(query));
        if (firstMatch) selectTreatmentForActiveLine(firstMatch.id);
      }
      if (event.key === "Escape") {
        modal.activeTreatmentPicker = null;
        modal.restoreTreatmentFocus = false;
        render();
      }
    });
  });
  document.querySelectorAll("[data-select-treatment]").forEach((btn) => btn.addEventListener("click", () => selectTreatmentForActiveLine(btn.dataset.selectTreatment)));
  if (modal.restoreTreatmentFocus && modal.activeTreatmentPicker !== null && modal.activeTreatmentPicker !== undefined) {
    const input = document.querySelector(`[data-treatment-search][data-line-index="${modal.activeTreatmentPicker}"]`);
    if (input) {
      modal.restoringTreatmentFocus = true;
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
      modal.restoringTreatmentFocus = false;
      modal.restoreTreatmentFocus = false;
    }
  }
}

function selectTreatmentForActiveLine(treatmentId) {
  syncAppointmentFromForm();
  const index = modal.activeTreatmentPicker;
  const treatment = state.treatments.find((t) => t.id === treatmentId);
  if (!treatment || index === null || index === undefined) return;
  modal.data.treatments[index] = {
    ...modal.data.treatments[index],
    treatmentId: treatment.id,
    duration: treatment.duration,
    price: treatment.defaultPrice,
    staffId: modal.data.treatments[index]?.staffId || modal.data.staffId
  };
  modal.treatmentQueries[index] = treatmentPickerLabel(treatment);
  modal.activeTreatmentPicker = null;
  recalcAppointmentFinance(false);
  render();
}

function refreshFinancePreview() {
  document.querySelector('[data-mini="base-price"]')?.replaceChildren(document.createTextNode(money(modal.data.basePrice)));
  document.querySelector('[data-mini="final-price"]')?.replaceChildren(document.createTextNode(money(modal.data.finalPrice)));
  document.querySelector('[data-mini="deposit"]')?.replaceChildren(document.createTextNode(money(modal.data.deposit)));
  document.querySelector('[data-mini="balance"]')?.replaceChildren(document.createTextNode(money(Math.max(0, Number(modal.data.finalPrice || 0) - Number(modal.data.deposit || 0)))));
  const finalPrice = document.querySelector('input[name="finalPrice"]');
  const basePrice = document.querySelector('input[name="basePrice"]');
  if (finalPrice) finalPrice.value = Number(modal.data.finalPrice || 0).toFixed(2);
  if (basePrice) basePrice.value = Number(modal.data.basePrice || 0).toFixed(2);
}

function syncAppointmentFromForm() {
  const form = document.getElementById("appointmentForm");
  const fd = new FormData(form);
  Object.assign(modal.data, {
    date: fd.get("date"),
    time: fd.get("time"),
    duration: Number(fd.get("duration")),
    staffId: fd.get("staffId"),
    status: fd.get("status"),
    paidStatus: fd.get("paidStatus"),
    treatmentPlanNotes: fd.get("treatmentPlanNotes"),
    deposit: Number(fd.get("deposit") || 0),
    priceOverride: fd.get("priceOverride") === "" ? null : Number(fd.get("priceOverride")),
    voucherSource: fd.get("voucherSource"),
    voucherCode: fd.get("voucherCode"),
    paymentMethod: fd.get("paymentMethod"),
    notes: fd.get("notes")
  });
  modal.data.treatments = [...document.querySelectorAll("[data-line]")].map((row) => {
    const index = Number(row.dataset.line);
    const treatmentInput = row.querySelector("[data-treatment-search]");
    const previousLine = modal.data.treatments[index] || {};
    const exactSelection = treatmentByPickerLabel(treatmentInput.value);
    const selected = exactSelection || state.treatments.find((t) => t.id === previousLine.treatmentId);
    const durationInput = row.querySelector("[data-line-duration]");
    const priceInput = row.querySelector("[data-line-price]");
    const staffInput = row.querySelector("[data-line-staff]");
    if (exactSelection && document.activeElement === treatmentInput) {
      durationInput.value = selected.duration;
      priceInput.value = selected.defaultPrice;
    }
    return {
      treatmentId: selected?.id || previousLine.treatmentId || "",
      duration: Number(durationInput.value || 0),
      staffId: staffInput?.value || previousLine.staffId || modal.data.staffId,
      price: Number(priceInput.value || 0)
    };
  });
  recalcAppointmentFinance(false);
  refreshFinancePreview();
}

function recalcAppointmentFinance(resetOverride) {
  const a = modal.data;
  a.basePrice = (a.treatments || []).reduce((sum, line) => sum + Number(line.price || 0), 0);
  a.duration = (a.treatments || []).reduce((sum, line) => sum + Number(line.duration || 0), 0) || a.duration || 30;
  if (resetOverride) a.priceOverride = null;
  a.finalPrice = a.priceOverride === null || a.priceOverride === "" || Number.isNaN(Number(a.priceOverride)) ? a.basePrice : Number(a.priceOverride);
}

function saveAppointmentForm(event, forceOverride) {
  event.preventDefault();
  syncAppointmentFromForm();
  if (!state.staff.length || !modal.data.staffId) return toast("Add a staff member before booking appointments");
  if (!modal.data.customerId) return toast("Select or create a client first");
  if (!modal.data.treatments.length || modal.data.treatments.some((line) => !line.treatmentId)) return toast("Select a treatment for every row");
  const conflict = hasOverlap(modal.data, modal.data.id);
  if (conflict && !forceOverride) {
    modal.conflict = conflict;
    render();
    return;
  }
  modal.data.override = Boolean(forceOverride || modal.data.override);
  if (modal.data.id) {
    state.appointments = state.appointments.map((a) => a.id === modal.data.id ? { ...modal.data } : a);
  } else {
    state.appointments.push({ ...modal.data, id: uid("appt") });
  }
  state.selectedDate = modal.data.date;
  modal = null;
  toast("Appointment saved");
  render();
}

function saveCustomerForm(event) {
  event.preventDefault();
  const fd = new FormData(event.target);
  const customer = {
    id: modal.data.id || uid("cust"),
    fullName: fd.get("fullName"),
    phone: fd.get("phone"),
    email: fd.get("email"),
    dob: fd.get("dob"),
    notes: fd.get("notes"),
    medicalHistory: fd.get("medicalHistory")
  };
  if (modal.data.id) {
    state.customers = state.customers.map((c) => c.id === customer.id ? customer : c);
  } else {
    state.customers.push(customer);
  }
  const appointmentDraft = modal.afterCreate;
  if (appointmentDraft) {
    modal = appointmentDraft;
    modal.data.customerId = customer.id;
    modal.customerQuery = customer.fullName;
  } else {
    modal = null;
  }
  toast("Client saved");
  render();
}

function saveTreatmentForm(event) {
  event.preventDefault();
  if (state.currentRole !== "Admin") return toast("Admin access required");
  const fd = new FormData(event.target);
  const treatment = {
    id: modal.data.id || uid("trt"),
    name: fd.get("name"),
    category: fd.get("category"),
    subcategory: fd.get("subcategory"),
    duration: Number(fd.get("duration")),
    defaultPrice: Number(fd.get("defaultPrice"))
  };
  state.treatments = modal.data.id ? state.treatments.map((t) => t.id === treatment.id ? treatment : t) : [...state.treatments, treatment];
  modal = null;
  toast("Treatment saved");
  render();
}

function saveStaffForm(event) {
  event.preventDefault();
  const fd = new FormData(event.target);
  const staff = {
    id: modal.data.id || uid("staff"),
    name: fd.get("name"),
    role: fd.get("role"),
    availability: fd.get("availability"),
    active: fd.get("active") === "true"
  };
  state.staff = modal.data.id ? state.staff.map((s) => s.id === staff.id ? staff : s) : [...state.staff, staff];
  modal = null;
  toast("Staff saved");
  render();
}

function deleteCustomer(id) {
  const client = state.customers.find((c) => c.id === id);
  if (!client) return toast("Client not found");
  if (state.appointments.some((a) => a.customerId === id)) return toast("Cannot delete client with existing appointments.");
  if (!confirm(`Delete client ${client.fullName}? This cannot be undone.`)) return;
  state.customers = state.customers.filter((c) => c.id !== id);
  toast("Client deleted");
  render();
}

function deleteStaff(id) {
  const staff = state.staff.find((s) => s.id === id);
  if (!staff) return toast("Staff member not found");
  const linked = state.appointments.some((a) => a.staffId === id || (a.treatments || []).some((line) => line.staffId === id));
  if (linked) {
    if (!confirm(`${staff.name} has linked appointments. They will be marked inactive instead of deleted. Continue?`)) return;
    state.staff = state.staff.map((s) => s.id === id ? { ...s, active: false } : s);
    toast("Staff member marked inactive");
    render();
    return;
  }
  if (!confirm(`Delete staff member ${staff.name}? This cannot be undone.`)) return;
  state.staff = state.staff.filter((s) => s.id !== id);
  toast("Staff member deleted");
  render();
}

function deleteTreatment(id) {
  if (state.currentRole !== "Admin") return toast("Admin access required");
  const used = state.appointments.some((appt) => (appt.treatments || []).some((line) => line.treatmentId === id));
  if (used) return toast("Cannot remove treatment used in appointments");
  state.treatments = state.treatments.filter((t) => t.id !== id);
  toast("Treatment removed");
  render();
}

function toggleTreatmentCategory(category) {
  const collapsed = new Set((sessionStorage.getItem("collapsedTreatmentCategories") || "").split("|").filter(Boolean));
  if (collapsed.has(category)) collapsed.delete(category);
  else collapsed.add(category);
  sessionStorage.setItem("collapsedTreatmentCategories", [...collapsed].join("|"));
  render();
}

render();
